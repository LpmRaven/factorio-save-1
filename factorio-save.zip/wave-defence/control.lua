local handler = require("event_handler")
handler.add_lib(require("wave_defense"))
